from Animal import Animal

class Carnivora(Animal):
    def __init__(self, name, hidup, berkembang_biak,jenis_makanan, jenis_kulit, jenis_warna):
        super().__init__(name, hidup, berkembang_biak, jenis_makanan)
        self.jenis_kulit= jenis_kulit
        self.jenis_warna = jenis_warna

    def info_carnivora(self):
        super().info_Animal()
        print("Jenis Kulit \t\t :", self.jenis_kulit,
              "\nJenis Warna \t\t :", self.jenis_warna)

komodo = Carnivora("komodo", "daging", "dua alam", "bertelur", "tebal","abu-abu") 
komodo.info_carnivora()
print("=================")
singa = Carnivora("singa", "daging", "darat", "melahirkan", "berbulu","coklat") 
singa.info_carnivora()
print("=================")
paus = Carnivora("paus", "daging", "air", "melahirkan", "tebal","abu-abu") 
paus.info_carnivora()



