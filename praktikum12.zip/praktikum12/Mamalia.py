from Animal import Animal
 
# setiap class child itu memiliki 2 properti dan method
class Mamalia(Animal):
    def __init__(self, name, makanan, hidup, berkembang_biak, ukuran_tubuh, jenis_kulit):
        super().__init__(name, makanan, hidup, berkembang_biak)
        self.ukuran_tubuh = ukuran_tubuh
        self.jenis_kulit = jenis_kulit

    def info_mamalia(self):
        super().info_Animal()
        print("ukuran_tubuh \t\t :", self.ukuran_tubuh,
              "\njenis_kulit \t\t :", self.jenis_kulit)

gajah = Mamalia("gajah", "tumbuh-tumbuhan", "darat", "melahirkan", "sangat besar", "sedikit berbulu")
gajah.info_mamalia()
print("==========================")
kucing = Mamalia("kucing", "ikan", "darat", "melahirkan", "sangat kecil", "berbulu")
kucing.info_mamalia()