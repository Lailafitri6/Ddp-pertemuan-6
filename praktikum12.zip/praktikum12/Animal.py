# Buat class animal sebagai parent class. class animal mempunyai properti 4 properti (name, makanan, hidup, berkembang biak)

class Animal:
    def __init__(self, name, makanan, hidup, berkembang_biak):
        self.name = name
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

    def info_Animal(self):
        print("Nama Hewan \t\t : ", self.name,
              "\nMakanan Hewan \t\t : ", self.makanan,
              "\nHidup \t\t\t : ", self.hidup,
              "\nBerkembang Biak \t : ", self.berkembang_biak)

# hewan = animal("Kucing lucu", "ikan", "darat", "melahirkan")
# hewan.info_animal()

